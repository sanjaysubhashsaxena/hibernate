package com.saxena.HQL;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class App {
	public static void main(String[] args) {

//		creatingRecords();
		fetchingRecords();
	}

	private static void creatingRecords() {
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Customer.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		for (int i = 100; i <= 150; i++) {
			Customer customer = new Customer();
			customer.setId(i);
			customer.setName("MyName " + i);
			customer.setAddress("MyCity " + i);
			session.save(customer);

		}
		session.getTransaction().commit();
		session.close();
	}

	private static void fetchingRecords() {
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Customer.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		Query q = session.createQuery("from Customer");
		List<Customer> customers = q.list();
		for (Customer eachcustomer : customers) {
			System.out.println(eachcustomer);
		}
		System.out.println("-------------------------------");
		Query query2 = session.createQuery("from Customer where id=136");
		Customer customer2 = (Customer) query2.uniqueResult();
		System.out.println("name " + customer2);
		
		System.out.println("-------------------------------");
		Query query3 = session.createQuery("select id,name,address from Customer where id=136");
		List<Object[]> customer3 = (List<Object[]>) query3.list();
		for (Object[] eachCustomer : customer3)
			System.out.println(eachCustomer[0] + " : " + eachCustomer[1] + ":" + eachCustomer[2]);
		
		System.out.println("-------------------------------");
		Query query4 = session.createQuery("select sum(id) from Customer where id=136");
		long sumOfId=(Long) query4.uniqueResult();
		System.out.println("Sum of IDs "+sumOfId);
		System.out.println("-------------------------------");
		
		int bcity=17;
		Query query5 = session.createQuery("select sum(id) from Customer cust where cust.id>:bcity");
		query5.setParameter("bcity", bcity);
		long sumOfId2 = (Long) query5.uniqueResult();
		System.out.println("Sum of IDs 2nd  "+sumOfId2);
		System.out.println("-------------------------------");
		
		session.getTransaction().commit();
		session.close();
	}
}
