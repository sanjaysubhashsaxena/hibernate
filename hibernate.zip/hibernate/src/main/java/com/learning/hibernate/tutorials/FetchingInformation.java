package com.learning.hibernate.tutorials;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class FetchingInformation {
	public static void fetchData() {
		// TODO Auto-generated method stub
		EmployeeInformation emp = null;
		Configuration configuration = new Configuration().configure().addAnnotatedClass(EmployeeInformation.class);
		ServiceRegistry sr =new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory factory = configuration.buildSessionFactory(sr);

		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();
		
		System.out.println(session.get(EmployeeInformation.class, 101));

		tx.commit();

		System.out.println(emp);
	}
}
