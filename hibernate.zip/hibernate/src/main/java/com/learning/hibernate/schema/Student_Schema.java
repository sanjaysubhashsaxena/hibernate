package com.learning.hibernate.schema;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.learning.hibernate.tutorials.StudentAddressSchema;

@Entity
@Table(name="StudentInfo")
public class Student_Schema {
	@Id
	private int id;
	private String name;
	private StudentAddressSchema address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public StudentAddressSchema getAddress() {
		return address;
	}
	public void setAddress(StudentAddressSchema address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Student_Schema [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	

}