package com.learning.hibernate.tutorials;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoringInformation {

	public static void StoreData() {
		EmployeeInformation employee = new EmployeeInformation();
		employee.setId(101);
		employee.setName("Sanjay");
		employee.setDesignation("Software Engineer");
		employee.setSalary(3.30f);
		Configuration con = new Configuration().configure().addAnnotatedClass(EmployeeInformation.class);

		SessionFactory sf = con.buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();

		session.save(employee);

		tx.commit();

		System.out.println("Your data save successfully!");

	}
}
