package com.learning.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.learning.hibernate.tutorials.AnnotationsUsed;
import com.learning.hibernate.tutorials.FetchingInformation;
import com.learning.hibernate.tutorials.StoringInformation;
import com.learning.hibernate.tutorials.CachingApplication;

public class App {
	public static void main(String[] args) {
//    	StoringInformation.StoreData();
		FetchingInformation.fetchData();
//		AnnotationsUsed.embeddableAnnotation();
//		test.display();
//		CachingApplication.storeData();
//		CachingApplication.firstLevelCache();
	}
}
