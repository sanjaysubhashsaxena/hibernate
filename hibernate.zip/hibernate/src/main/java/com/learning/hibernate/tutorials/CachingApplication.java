package com.learning.hibernate.tutorials;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.learning.hibernate.schema.Student;

public class CachingApplication {
	public static void storeData() {
		System.out.println("Inside method");
		Student student =new Student();
		student.setId(101);
		student.setAddress("Bhopal");
		student.setName("TestName");
		
		Configuration con = new Configuration().configure().addAnnotatedClass(Student.class);

		SessionFactory sf = con.buildSessionFactory();

		Session session = sf.openSession();

		Transaction tx = session.beginTransaction();

		session.save(student);

		tx.commit();

		System.out.println("Your data save successfully!");
	}
	
	public static void firstLevelCache() {
		EmployeeInformation emp = null;
		Configuration configuration = new Configuration().configure().addAnnotatedClass(EmployeeInformation.class);
		ServiceRegistry sr =new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory factory = configuration.buildSessionFactory(sr);

		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();
		
		emp = (EmployeeInformation) session.get(EmployeeInformation.class, 101);
		
		System.out.println(emp);

		tx.commit();
		session.close();
//		2nd Session
		Session session2 = factory.openSession();

		Transaction tx2 = session.beginTransaction();
		
		emp = (EmployeeInformation) session2.get(EmployeeInformation.class, 101);
		System.out.println(emp);

		tx2.commit();
		session2.close();

	}
}
