package com.learning.hibernate.tutorials;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.hibernate.schema.CollegeStudent_Schema;
import com.learning.hibernate.schema.CollegeStudent_Schema2;
import com.learning.hibernate.schema.CollegeStudent_Schema3;
import com.learning.hibernate.schema.Laptop_Schema;
import com.learning.hibernate.schema.Laptop_Schema2;

public class RelationalMapping {
	public void manytoone() {
		Laptop_Schema2 laptop = new Laptop_Schema2();
		CollegeStudent_Schema3 student = new CollegeStudent_Schema3();
		laptop.setLid(111);
		laptop.setLname("HP");
		student.setId(101);
		student.setName("TestName");
		student.setMarks(100);
//		student.getLaptop().add(laptop);
		laptop.getLstudent().add(student);
		Configuration configuration = new Configuration().configure().addAnnotatedClass(CollegeStudent_Schema3.class)
				.addAnnotatedClass(Laptop_Schema2.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(laptop);
		session.save(student);
		tx.commit();
		
	}

	public void onetomany() {
		Laptop_Schema laptop = new Laptop_Schema();
		laptop.setLid(111);
		laptop.setLname("HP");
		CollegeStudent_Schema2 student = new CollegeStudent_Schema2();
		student.setId(101);
		student.setName("TestName");
		student.setMarks(100);
		student.getLaptop().add(laptop);
		Configuration configuration = new Configuration().configure().addAnnotatedClass(CollegeStudent_Schema2.class)
				.addAnnotatedClass(Laptop_Schema.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(laptop);
		session.save(student);
		tx.commit();
		
	}

	public void onetoone() {
		Laptop_Schema laptop = new Laptop_Schema();
		laptop.setLid(111);
		laptop.setLname("HP");
		CollegeStudent_Schema student = new CollegeStudent_Schema();
		student.setId(101);
		student.setName("TestName");
		student.setMarks(100);
		student.setLaptop(laptop);
		Configuration configuration = new Configuration().configure().addAnnotatedClass(CollegeStudent_Schema.class)
				.addAnnotatedClass(Laptop_Schema.class);
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(laptop);
		session.save(student);
		tx.commit();

	}
}