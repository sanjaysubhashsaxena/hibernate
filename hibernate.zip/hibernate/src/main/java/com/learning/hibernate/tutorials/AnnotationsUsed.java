package com.learning.hibernate.tutorials;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.hibernate.schema.Student_Schema;

public class AnnotationsUsed {
	public static void embeddableAnnotation() {
		/*
		 * Embeddable Annotation is used to store object of class to another class and
		 * add extra column in the database
		 */
		StudentAddressSchema address = new StudentAddressSchema();
		address.setHouseNo(100);
		address.setCity("Bhopal");
		address.setState("Madhya Pradesh");

		Student_Schema student = new Student_Schema();
		student.setId(99);
		student.setName("Sanjay");
		student.setAddress(address);

		Configuration configuration = new Configuration().configure().addAnnotatedClass(Student_Schema.class);

		SessionFactory factory = configuration.buildSessionFactory();

		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();

		session.save(student);

		tx.commit();

	}
}
