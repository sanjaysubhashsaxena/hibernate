package com.learning.hibernate.tutorials;

import javax.persistence.Embeddable;

@Embeddable
public class StudentAddressSchema {
	private int houseNo;
	private String city;
	private String State;

	public int getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

}
