package com.learning.hibernate.tutorials;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.learning.hibernate.schema.Laptop_SchemaFT;
import com.learning.hibernate.schema.Student_SchemaFT;

public class TypesOfFetchingTechniques {
	public static void EagerFetching32() {
		// In the EagerFetching, Hibernate fire the single queried to db to retrive the data
		//By Default it's using Left outer join and we are mentioning keyword fetch=FetchType.EAGER in
		// the schema
		Student_SchemaFT student=new Student_SchemaFT();
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Student_SchemaFT.class).addAnnotatedClass(Laptop_SchemaFT.class);
		SessionFactory factory= configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(student);
		tx.commit();
	}

	public static void LazyFetching() {
		// In the Lazy Fetch, Hibernate fire the multiple queries to db to retrive the data
	}
}
