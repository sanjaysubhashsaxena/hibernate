package com.learning.hibernate.schema;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Student_SchemaFT {
	@Id
	private int sid;
	private String sname;
	@OneToMany(mappedBy="Student_SchemaFT",fetch=FetchType.EAGER)
	private Collection<Laptop_SchemaFT> slaptop = new ArrayList<Laptop_SchemaFT>();

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Collection<Laptop_SchemaFT> getSlaptop() {
		return slaptop;
	}

	public void setSlaptop(Collection<Laptop_SchemaFT> slaptop) {
		this.slaptop = slaptop;
	}

}
