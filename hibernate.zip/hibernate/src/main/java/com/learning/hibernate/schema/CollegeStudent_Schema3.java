package com.learning.hibernate.schema;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="student")
public class CollegeStudent_Schema3 {
	@Id
	private int id;
	private String name;
	private int marks;
	@OneToMany(mappedBy="laptop2")
	private List<Laptop_Schema> Laptop = new ArrayList<Laptop_Schema>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public List<Laptop_Schema> getLaptop() {
		return Laptop;
	}

	public void setLaptop(List<Laptop_Schema> laptop) {
		Laptop = laptop;
	}

}
