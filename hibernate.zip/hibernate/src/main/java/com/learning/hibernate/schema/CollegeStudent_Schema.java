package com.learning.hibernate.schema;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CollegeStudent")
public class CollegeStudent_Schema {
	@Id
	private int id;
	private String name;
	private int marks;
	@OneToOne
	private Laptop_Schema Laptop;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return marks;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public Laptop_Schema getLaptop() {
		return Laptop;
	}

	public void setLaptop(Laptop_Schema laptop) {
		Laptop = laptop;
	}

}
