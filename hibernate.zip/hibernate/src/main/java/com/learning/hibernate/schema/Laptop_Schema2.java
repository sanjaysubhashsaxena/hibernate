package com.learning.hibernate.schema;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "laptop")
public class Laptop_Schema2 {
	@Id
	private int lid;
	private String lname;
	@ManyToOne
	private List<CollegeStudent_Schema3> lstudent = new ArrayList<CollegeStudent_Schema3>();

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public List<CollegeStudent_Schema3> getLstudent() {
		return lstudent;
	}

	public void setLstudent(List<CollegeStudent_Schema3> lstudent) {
		this.lstudent = lstudent;
	}

}
