package com.saxena.JPAImplementation;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {  	
    	storingData();
    	fetchingData();
    }

	private static void storingData() {
		Customer customer = new Customer();
		customer.setId(101);
		customer.setFirstName("TestFirstName");
		customer.setLastName("TestLastName");
		customer.setPhoneNo("+919000000000");
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAImp");
    	EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(customer);
		em.getTransaction().commit();
	}

	private static void fetchingData() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAImp");
    	EntityManager em=emf.createEntityManager();
    	Customer customer = em.find(Customer.class, 101);
        System.out.println(customer);
	}
}
