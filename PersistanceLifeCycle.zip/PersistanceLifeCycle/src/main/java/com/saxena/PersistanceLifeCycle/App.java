package com.saxena.PersistanceLifeCycle;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration configuration = new Configuration().configure().addAnnotatedClass(Customer.class);
    	SessionFactory factory = configuration.buildSessionFactory();
    	Session session = factory.openSession();
    	Transaction tx = session.beginTransaction();
        Customer customer =new Customer();
        customer.setId(101);
        customer.setName("TestName");
        customer.setAddress("Madhya Pradesh");
        // Upto here object are in Transient state
        
        session.save(customer);
        customer.setAddress("Maharastra"); // Update query executed
        // Object is in Persistance state
        tx.commit();
        customer.setAddress("Karnataka");
        // Object is in Detached state
    
    }
}
